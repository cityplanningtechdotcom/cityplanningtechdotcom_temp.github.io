---
title: About
permalink: /about/
---

<p class="heavy-title"><a href="http://github.com/thinker3197/Ink">Ink</a> is a simple & minimalistic theme for <a href="http://jekyllrb.com">Jekyll</a>, a static site generator.</p>

>Designed and developed by [@thinker3197](https://github.com/thinker3197).
